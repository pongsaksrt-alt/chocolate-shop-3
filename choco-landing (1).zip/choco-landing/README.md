# Cocoa Craft — โปรเจกต์ 007 (Landing Page ช็อกโกแลตแท่ง)

## โครงสร้างไฟล์
```
index.html        หน้าแลนดิงเพจ (ลูกค้า)
admin.html        หน้าหลังบ้าน: รายการหยิบสินค้า + พิมพ์ใบจ่าหน้าพัสดุ
config.js         ใส่ URL ของ Apps Script ที่นี่
images/           โฟลเดอร์รูปสินค้า (แยกจากโค้ด)
apps-script/      Code.gs + Products.csv + Orders-header.csv
```

## ขั้นที่ 1: Google Sheet
1. สร้าง Google Sheet ใหม่ ตั้งชื่ออะไรก็ได้
2. แท็บแรกเปลี่ยนชื่อเป็น `Products` → File > Import > Upload `apps-script/Products.csv` (เลือก Replace current sheet)
3. สร้างแท็บใหม่ชื่อ `Orders` → วางหัวคอลัมน์จาก `Orders-header.csv` ในแถวที่ 1
   (OrderID, Timestamp, Name, Phone, Address, Postal, Items, Total, Status)

## ขั้นที่ 2: Apps Script
1. ในชีต: Extensions > Apps Script
2. ลบโค้ดเดิม วางเนื้อหา `apps-script/Code.gs` แล้วกด Save
3. Deploy > New deployment > ประเภท Web app
   - Execute as: Me
   - Who has access: Anyone
4. กด Deploy → อนุญาตสิทธิ์ → คัดลอก URL ที่ลงท้าย `/exec`
5. เปิด `config.js` แล้ววางใน `window.APP_URL = "..."`

## ขั้นที่ 3: รูปสินค้า
ใส่รูปจริงในโฟลเดอร์ `images/` (เช่น dark.jpg) แล้วแก้คอลัมน์ `image` ในชีตเป็น `images/dark.jpg`

## ขั้นที่ 4: GitHub
```
git init
git add .
git commit -m "chocolate landing page"
git branch -M main
git remote add origin https://github.com/<user>/<repo>.git
git push -u origin main
```
(หรือสร้าง repo บนเว็บแล้วลากไฟล์ทั้งหมดอัปโหลดก็ได้)

## ขั้นที่ 5: Vercel
1. vercel.com > Add New > Project > Import repo ที่เพิ่ง push
2. Framework Preset: Other (ไม่ต้องตั้ง build) → Deploy
3. ได้โดเมน `https://<ชื่อ>.vercel.app` — ส่งลิงก์นี้ + ลิงก์ GitHub

## ใช้งานหลังบ้าน (หยิบ-แพ็ก-ส่ง)
เปิด `https://<โดเมน>/admin.html` → ระบบดึงออเดอร์จากชีต → ดู "รายการที่ต้องหยิบ" →
กด "พิมพ์ใบจ่าหน้าพัสดุ" (ขนาด A6) → แพ็กเสร็จกด "แพ็กแล้ว" (สถานะในชีตเปลี่ยนเป็น PACKED)
แก้ที่อยู่ร้านผู้ส่งใน `admin.html` ตัวแปร `SENDER`
