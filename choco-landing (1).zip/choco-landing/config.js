// ===== ตั้งค่าตรงนี้ที่เดียว =====
// 1) วาง URL ของ Google Apps Script (Web app) ที่ได้หลัง Deploy (ลงท้ายด้วย /exec)
//    ถ้ายังเว้นว่าง เว็บจะใช้ข้อมูลตัวอย่างด้านล่าง (โหมดทดลอง) และเก็บออเดอร์ไว้ใน localStorage
window.APP_URL = "";

// 2) รหัสผ่านแอดมิน (ต้องตรงกับ ADMIN_KEY ใน Code.gs)
window.ADMIN_KEY = "choco1234";

// ข้อมูลสำรอง (ใช้เมื่อยังไม่ได้ตั้ง APP_URL) — โครงสร้างเดียวกับชีต "Products"
window.FALLBACK_PRODUCTS = [
  { sku: "CHOC-DARK70", name: "ดาร์กช็อกโกแลต 70%", price: 89, stock: 50, image: "images/dark-70.svg",
    desc: "เข้มข้น หอมโกโก้แท้ ขมกำลังดี หวานน้อย เหมาะกับสายเฮลตี้ (80 กรัม)" },
  { sku: "CHOC-MILKHZ", name: "มิลค์ช็อกโกแลต เฮเซลนัท", price: 99, stock: 40, image: "images/milk-hazelnut.svg",
    desc: "นมเนียนนุ่ม เคี้ยวเพลินกับเฮเซลนัทอบกรอบ ละลายในปาก (80 กรัม)" }
];
